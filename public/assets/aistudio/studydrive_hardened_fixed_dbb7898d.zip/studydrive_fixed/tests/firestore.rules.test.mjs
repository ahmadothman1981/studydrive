import { before, after, beforeEach, test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {
  initializeTestEnvironment,
  assertSucceeds,
  assertFails,
} from '@firebase/rules-unit-testing';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  setDoc,
  where,
  serverTimestamp,
} from 'firebase/firestore';

const PROJECT_ID = 'demo-studydrive';
let env;

function dbFor(ctx) {
  return ctx.firestore();
}

function profile(uid, status, allowedFolderIds = [], role = 'student') {
  return {
    userId: uid,
    displayName: uid,
    email: `${uid}@example.com`,
    status,
    role,
    activeFolderId: 'study_materials_root',
    activeFolderName: 'Study Materials',
    allowedFolderIds,
    createdAt: new Date('2025-01-01T00:00:00Z'),
    updatedAt: new Date('2025-01-01T00:00:00Z'),
  };
}

before(async () => {
  env = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules: fs.readFileSync(new URL('../firestore.rules', import.meta.url), 'utf8'),
      host: '127.0.0.1',
      port: 8085,
    },
  });
});

after(async () => { await env?.cleanup(); });

beforeEach(async () => {
  await env.clearFirestore();
  await env.withSecurityRulesDisabled(async (context) => {
    const db = dbFor(context);
    await setDoc(doc(db, 'users/pending-student'), profile('pending-student', 'pending', ['folder-a']));
    await setDoc(doc(db, 'users/rejected-student'), profile('rejected-student', 'rejected', ['folder-a']));
    await setDoc(doc(db, 'users/assigned-student'), profile('assigned-student', 'approved', ['folder-a']));
    await setDoc(doc(db, 'users/unassigned-student'), profile('unassigned-student', 'approved', ['folder-b']));
    await setDoc(doc(db, 'admin_materials/material-a'), {
      fileId: 'material-a', name: 'lesson.pdf', category: 'Python', mimeType: 'application/pdf',
      storagePath: 'materials/folder-a/material-a/lesson.pdf', sizeBytes: 1024, folderId: 'folder-a',
      createdAt: new Date('2025-01-01T00:00:00Z'),
    });
    await setDoc(doc(db, 'admin_materials/material-b'), {
      fileId: 'material-b', name: 'other.pdf', category: 'Python', mimeType: 'application/pdf',
      storagePath: 'materials/folder-b/material-b/other.pdf', sizeBytes: 1024, folderId: 'folder-b',
      createdAt: new Date('2025-01-01T00:00:00Z'),
    });
  });
});

test('signed-out users cannot read protected materials', async () => {
  await assertFails(getDoc(doc(dbFor(env.unauthenticatedContext()), 'admin_materials/material-a')));
});

test('pending and rejected students cannot read study materials', async () => {
  for (const uid of ['pending-student', 'rejected-student']) {
    const ctx = env.authenticatedContext(uid, { email: `${uid}@example.com`, email_verified: true });
    await assertFails(getDoc(doc(dbFor(ctx), 'admin_materials/material-a')));
  }
});

test('approved students can read only material in assigned folders', async () => {
  const ctx = env.authenticatedContext('assigned-student', { email: 'assigned-student@example.com', email_verified: true });
  const db = dbFor(ctx);
  await assertSucceeds(getDoc(doc(db, 'admin_materials/material-a')));
  await assertFails(getDoc(doc(db, 'admin_materials/material-b')));
  await assertSucceeds(getDocs(query(collection(db, 'admin_materials'), where('folderId', '==', 'folder-a'))));
  await assertFails(getDocs(collection(db, 'admin_materials')));
});

test('download history cannot store device-specific absolute paths', async () => {
  const ctx = env.authenticatedContext('assigned-student', { email: 'assigned-student@example.com', email_verified: true });
  const db = dbFor(ctx);
  await assertSucceeds(setDoc(doc(db, 'users/assigned-student/downloads/material-a'), {
    fileId: 'material-a', fileName: 'lesson.pdf', mimeType: 'application/pdf',
    fileSizeBytes: 1024, userId: 'assigned-student', downloadedAt: serverTimestamp(),
  }));
  await assertFails(setDoc(doc(db, 'users/assigned-student/downloads/material-b'), {
    fileId: 'material-b', fileName: 'lesson.pdf', mimeType: 'application/pdf',
    fileSizeBytes: 1024, localFilePath: '/data/user/0/app/files/lesson.pdf',
    userId: 'assigned-student', downloadedAt: serverTimestamp(),
  }));
});

test('students cannot self-approve or grant themselves admin roles', async () => {
  const ctx = env.authenticatedContext('assigned-student', { email: 'assigned-student@example.com', email_verified: true });
  const db = dbFor(ctx);
  await assertFails(setDoc(doc(db, 'users/assigned-student'), {
    ...profile('assigned-student', 'approved', ['folder-a'], 'admin'), updatedAt: serverTimestamp(),
  }));
});

test('only a claimed super-admin can create invites; the invited verified user can accept their own invite', async () => {
  const root = env.authenticatedContext('root-uid', { super_admin: true, email: 'root@example.com', email_verified: true });
  const rootDb = dbFor(root);
  await assertSucceeds(setDoc(doc(rootDb, 'admin_invites/new-admin@example.com'), {
    email: 'new-admin@example.com', addedBy: 'root@example.com', role: 'admin', createdAt: serverTimestamp(),
  }));
  const invitee = env.authenticatedContext('new-admin-uid', { email: 'new-admin@example.com', email_verified: true });
  const inviteeDb = dbFor(invitee);
  await assertSucceeds(getDoc(doc(inviteeDb, 'admin_invites/new-admin@example.com')));
  await assertSucceeds(setDoc(doc(inviteeDb, 'admins/new-admin-uid'), {
    email: 'new-admin@example.com', addedBy: 'root@example.com', role: 'admin', createdAt: serverTimestamp(),
  }));
  await assertSucceeds(getDoc(doc(inviteeDb, 'admin_materials/material-a')));
  await assertSucceeds((async () => {
    const { deleteDoc } = await import('firebase/firestore');
    return deleteDoc(doc(inviteeDb, 'admin_invites/new-admin@example.com'));
  })());
});

test('delegated admin can approve pending students and assign folders but cannot escalate roles', async () => {
  const root = env.authenticatedContext('root-uid', { super_admin: true, email: 'root@example.com', email_verified: true });
  await assertSucceeds(setDoc(doc(dbFor(root), 'admins/assistant-uid'), {
    email: 'assistant@example.com', addedBy: 'root@example.com', role: 'admin', createdAt: serverTimestamp(),
  }));

  const assistant = env.authenticatedContext('assistant-uid', { email: 'assistant@example.com', email_verified: true });
  const assistantDb = dbFor(assistant);

  await assertSucceeds(setDoc(doc(assistantDb, 'users/pending-student'), {
    ...profile('pending-student', 'approved', ['folder-a', 'folder-b'], 'student'),
    updatedAt: serverTimestamp(),
  }));

  await assertFails(setDoc(doc(assistantDb, 'users/pending-student'), {
    ...profile('pending-student', 'approved', ['folder-a'], 'admin'),
    updatedAt: serverTimestamp(),
  }));
});

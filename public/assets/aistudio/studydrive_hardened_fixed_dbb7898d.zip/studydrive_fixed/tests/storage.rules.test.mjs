import { before, after, beforeEach, test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { initializeTestEnvironment, assertSucceeds, assertFails } from '@firebase/rules-unit-testing';
import { ref, uploadBytes, getBytes } from 'firebase/storage';

const PROJECT_ID = 'demo-studydrive';
const PATH_ASSIGNED = 'materials/folder-a/material-a/test.pdf';
const PATH_UNASSIGNED = 'materials/folder-b/material-b/test.pdf';
let env;

function storageFor(ctx) { return ctx.storage(); }

before(async () => {
  env = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules: fs.readFileSync(new URL('../firestore.rules', import.meta.url), 'utf8'),
      host: '127.0.0.1',
      port: 8085,
    },
    storage: {
      rules: fs.readFileSync(new URL('../storage.rules', import.meta.url), 'utf8'),
      host: '127.0.0.1',
      port: 9199,
    },
  });
});

after(async () => { await env?.cleanup(); });

beforeEach(async () => {
  await env.withSecurityRulesDisabled(async (context) => {
    const storage = storageFor(context);
    const bytes = new Uint8Array([37, 80, 68, 70, 45, 49, 46, 55]);
    await uploadBytes(ref(storage, PATH_ASSIGNED), bytes, { contentType: 'application/pdf' });
    await uploadBytes(ref(storage, PATH_UNASSIGNED), bytes, { contentType: 'application/pdf' });
  });
});

test('signed-out users cannot download protected study files', async () => {
  const storage = storageFor(env.unauthenticatedContext());
  await assertFails(getBytes(ref(storage, PATH_ASSIGNED)));
});

test('pending or rejected users cannot download files even if a folder ID is present', async () => {
  for (const statusClaims of [
    { approved: false, allowed_folder_ids: ['folder-a'] },
    { approved: false, allowed_folder_ids: [] },
  ]) {
    const context = env.authenticatedContext('student-pending', statusClaims);
    await assertFails(getBytes(ref(storageFor(context), PATH_ASSIGNED)));
  }
});

test('approved students can read only files from assigned folders', async () => {
  const context = env.authenticatedContext('student-assigned', {
    approved: true,
    allowed_folder_ids: ['folder-a'],
  });
  const storage = storageFor(context);
  const bytes = await assertSucceeds(getBytes(ref(storage, PATH_ASSIGNED)));
  assert.equal(bytes.length, 8);
  await assertFails(getBytes(ref(storage, PATH_UNASSIGNED)));
});

test('only administrators can upload valid-sized supported study files', async () => {
  const admin = env.authenticatedContext('administrator', { admin: true, approved: true });
  await assertSucceeds(uploadBytes(
    ref(storageFor(admin), 'materials/folder-a/new-material/uploaded.pdf'),
    new Uint8Array([1, 2, 3]),
    { contentType: 'application/pdf' },
  ));
  const student = env.authenticatedContext('student-assigned', {
    approved: true,
    allowed_folder_ids: ['folder-a'],
  });
  await assertFails(uploadBytes(
    ref(storageFor(student), 'materials/folder-a/forbidden/uploaded.pdf'),
    new Uint8Array([1, 2, 3]),
    { contentType: 'application/pdf' },
  ));
  await assertFails(uploadBytes(
    ref(storageFor(admin), 'materials/folder-a/unsupported/uploaded.exe'),
    new Uint8Array([1, 2, 3]),
    { contentType: 'application/x-msdownload' },
  ));
});

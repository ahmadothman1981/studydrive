package com.example.ui.studydrive

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AdminMaterial
import com.example.data.model.DownloadedFile
import com.example.data.model.DriveFile
import com.example.data.model.StudyAnnouncement
import com.example.data.model.StudyBookmark
import com.example.data.model.SubjectFolder
import com.example.data.repository.DriveRepository
import com.example.data.repository.StudyRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

data class DriveScreenState(
    val files: List<DriveFile> = emptyList(),
    val isLoading: Boolean = false,
    val searchQuery: String = "",
    val selectedCategory: String = "All",
    val selectedFileType: String = "All",
    val selectedSemester: String = "All",
    val selectedAcademicYear: String = "All",
    val selectedProfessor: String = "All",
    val selectedCourse: String = "All",
    val selectedDepartment: String = "All",
    val activeFolderId: String = "study_materials_root",
    val activeFolderName: String = "Study Materials",
    val downloadProgress: Map<String, Float> = emptyMap(),
    val totalStorageUsedBytes: Long = 0L,
    val errorMessage: String? = null
) {
    val activeFilterCount: Int
        get() {
            var count = 0
            if (searchQuery.isNotBlank()) count++
            if (selectedCategory != "All") count++
            if (selectedFileType != "All") count++
            if (selectedSemester != "All") count++
            if (selectedAcademicYear != "All") count++
            if (selectedProfessor != "All") count++
            if (selectedCourse != "All") count++
            if (selectedDepartment != "All") count++
            return count
        }
}



class DriveViewModel(
    private val driveRepository: DriveRepository,
    private val studyRepository: StudyRepository,
    private val currentUserId: String
) : ViewModel() {

    companion object {
        private const val TAG = "DriveViewModel"
    }

    private val _screenState = MutableStateFlow(DriveScreenState(isLoading = true))
    val screenState: StateFlow<DriveScreenState> = _screenState.asStateFlow()

    val downloadedFiles: StateFlow<List<DownloadedFile>> = studyRepository.observeDownloads(currentUserId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookmarks: StateFlow<List<StudyBookmark>> = studyRepository.observeBookmarks(currentUserId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val adminMaterials: StateFlow<List<AdminMaterial>> = studyRepository.observeAdminMaterials(currentUserId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val studentsPageSize: StateFlow<Int> = studyRepository.studentsPageSize
    val materialsPageSize: StateFlow<Int> = studyRepository.materialsPageSize

    fun loadMoreStudents() = studyRepository.loadMoreStudents()
    fun loadMoreAdminMaterials() = studyRepository.loadMoreAdminMaterials()

    val userProfile: StateFlow<com.example.data.model.UserProfile?> = studyRepository.observeUserProfile(currentUserId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _statusOverrides = MutableStateFlow<Map<String, String>>(emptyMap())
    private val _studentFoldersOverrides = MutableStateFlow<Map<String, List<String>>>(emptyMap())

    val allStudents: StateFlow<List<com.example.data.model.UserProfile>> = combine(
        studyRepository.observeAllStudents(currentUserId),
        _statusOverrides,
        _studentFoldersOverrides
    ) { list, overrides, folderOverrides ->
        list.map { student ->
            var updated = student
            overrides[student.userId]?.let { updated = updated.copy(status = it) }
            folderOverrides[student.userId]?.let { updated = updated.copy(allowedFolderIds = it) }
            updated
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val admins: StateFlow<List<com.example.data.model.AdminUser>> = studyRepository.observeAdmins(currentUserId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val announcements: StateFlow<List<StudyAnnouncement>> = studyRepository.observeAnnouncements(currentUserId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val defaultSubjectFolders = listOf(
        SubjectFolder(
            id = "study_materials_root",
            folderId = "study_materials_root",
            name = "جميع المواد والمجلدات (الرئيسي)",
            subject = "All",
            department = "All",
            grade = "جميع الصفوف",
            description = "المجلد الرئيسي الشامل لجميع المذكرات والملفات الدراسية"
        ),
        SubjectFolder(
            id = "folder_python_1",
            folderId = "folder_python_1",
            name = "مجلد لغة بايثون (Python)",
            subject = "Python",
            department = "Computer Science",
            grade = "الصف الأول الثانوي",
            description = "شرح ومذكرات لغة بايثون، المتغيرات، الشروط والحلقات التكرارية"
        ),
        SubjectFolder(
            id = "folder_algo_2",
            folderId = "folder_algo_2",
            name = "مجلد الخوارزميات وهياكل البيانات",
            subject = "Algorithms",
            department = "Computer Science",
            grade = "الصف الثاني الثانوي",
            description = "خرائط التدفق Flowcharts وتصميم الخوارزميات والبرمجة الكائنية"
        ),
        SubjectFolder(
            id = "folder_exams_bac",
            folderId = "folder_exams_bac",
            name = "مجلد بنك أسئلة وامتحانات البكالوريا",
            subject = "Past Exams",
            department = "General Secondary",
            grade = "جميع الصفوف",
            description = "نماذج الامتحانات الرسمية السابقة مع الحلول النموذجية"
        ),
        SubjectFolder(
            id = "folder_web_html",
            folderId = "folder_web_html",
            name = "مجلد تطوير الويب HTML5 & CSS3",
            subject = "Web Development",
            department = "Engineering",
            grade = "الصف الأول الثانوي",
            description = "تصميم وتطوير صفحات ومواقع الويب التفاعلية"
        ),
        SubjectFolder(
            id = "folder_db_sql",
            folderId = "folder_db_sql",
            name = "مجلد قواعد البيانات SQL",
            subject = "Database",
            department = "Business",
            grade = "الصف الثاني الثانوي",
            description = "أساسيات قواعد البيانات العلائقية واستعلامات SQL"
        )
    )

    private val _folderUpsertOverrides = MutableStateFlow<Map<String, SubjectFolder>>(emptyMap())
    private val _deletedFolderIds = MutableStateFlow<Set<String>>(emptySet())

    val subjectFolders: StateFlow<List<SubjectFolder>> = combine(
        studyRepository.observeSubjectFolders(currentUserId),
        _folderUpsertOverrides,
        _deletedFolderIds,
        userProfile
    ) { remoteList, upserts, deletedIds, profile ->
        val mergedMap = linkedMapOf<String, SubjectFolder>()
        defaultSubjectFolders.forEach { folder ->
            val key = folder.folderId.ifBlank { folder.id }
            mergedMap[key] = folder
        }
        remoteList.forEach { folder ->
            val key = folder.folderId.ifBlank { folder.id }
            if (key.isNotBlank()) mergedMap[key] = folder.copy(id = key, folderId = key)
        }
        upserts.forEach { (key, folder) -> mergedMap[key] = folder }
        deletedIds.forEach { key -> if (key != "study_materials_root") mergedMap.remove(key) }
        if (profile == null) emptyList() else if (profile.isAdmin) mergedMap.values.toList()
        else mergedMap.values.filter { (it.folderId.ifBlank { it.id }) in profile.allowedFolderIds }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun createSubjectFolder(
        name: String,
        subject: String,
        department: String,
        grade: String,
        description: String,
        driveFolderUrl: String = "" // Retained for source compatibility; Drive URL linking is disabled.
    ) {
        // Folder IDs are generated locally and never derived from a user-supplied URL.
        val cleanId = "folder_subj_${System.currentTimeMillis()}"
        val newFolder = SubjectFolder(
            id = cleanId,
            folderId = cleanId,
            name = name.trim(),
            subject = subject.trim().ifBlank { "Python" },
            department = department.trim().ifBlank { "Computer Science" },
            grade = grade.trim().ifBlank { "جميع الصفوف" },
            description = description.trim(),
            driveFolderUrl = ""
        )
        _deletedFolderIds.value = _deletedFolderIds.value - cleanId
        _folderUpsertOverrides.value = _folderUpsertOverrides.value + (cleanId to newFolder)

        viewModelScope.launch {
            try {
                studyRepository.saveSubjectFolder(newFolder)
            } catch (e: Exception) {
                Log.e(TAG, "Error creating subject folder in Firestore: ${e.message}", e)
            }
        }
    }

    fun updateSubjectFolder(folder: SubjectFolder) {
        val cleanId = folder.folderId.ifBlank { folder.id }
        if (cleanId.isBlank()) return
        val updatedFolder = folder.copy(id = cleanId, folderId = cleanId)
        _folderUpsertOverrides.value = _folderUpsertOverrides.value + (cleanId to updatedFolder)

        if (_screenState.value.activeFolderId == cleanId) {
            _screenState.value = _screenState.value.copy(activeFolderName = updatedFolder.name)
        }

        viewModelScope.launch {
            try {
                studyRepository.updateSubjectFolder(updatedFolder)
            } catch (e: Exception) {
                Log.e(TAG, "Error updating subject folder in Firestore: ${e.message}", e)
            }
        }
    }

    fun deleteSubjectFolder(folderId: String) {
        val cleanId = folderId.trim()
        if (cleanId.isBlank() || cleanId == "study_materials_root") return

        _deletedFolderIds.value = _deletedFolderIds.value + cleanId
        _folderUpsertOverrides.value = _folderUpsertOverrides.value - cleanId

        if (_screenState.value.activeFolderId == cleanId) {
            changeFolder("study_materials_root", "جميع المواد والمجلدات (الرئيسي)")
        }

        viewModelScope.launch {
            try {
                studyRepository.deleteSubjectFolder(cleanId)
            } catch (e: Exception) {
                Log.e(TAG, "Error deleting subject folder in Firestore: ${e.message}", e)
            }
        }
    }

    private val _showApprovalBanner = MutableStateFlow(true)
    val showApprovalBanner: StateFlow<Boolean> = _showApprovalBanner.asStateFlow()

    fun dismissApprovalBanner() {
        _showApprovalBanner.value = false
    }

    init {
        loadFiles()
        observeProfile()
        observeAdminMaterials()
    }

    fun approveStudent(studentId: String) {
        _statusOverrides.value = _statusOverrides.value + (studentId to "approved")
        viewModelScope.launch {
            try {
                studyRepository.updateUserStatus(studentId, "approved")
            } catch (e: Exception) {
                Log.e(TAG, "Error approving student: ${e.message}", e)
                _statusOverrides.value = _statusOverrides.value - studentId
            }
        }
    }

    fun approveStudentWithFolders(studentId: String, allowedFolderIds: List<String>) {
        _statusOverrides.value = _statusOverrides.value + (studentId to "approved")
        _studentFoldersOverrides.value = _studentFoldersOverrides.value + (studentId to allowedFolderIds)
        viewModelScope.launch {
            try {
                studyRepository.approveStudentWithFolders(studentId, allowedFolderIds)
            } catch (e: Exception) {
                Log.e(TAG, "Error approving student with folders: ${e.message}", e)
                _statusOverrides.value = _statusOverrides.value - studentId
            }
        }
    }

    fun assignStudentFolders(studentId: String, allowedFolderIds: List<String>) {
        _studentFoldersOverrides.value = _studentFoldersOverrides.value + (studentId to allowedFolderIds)
        viewModelScope.launch {
            try {
                studyRepository.updateStudentAllowedFolders(studentId, allowedFolderIds)
            } catch (e: Exception) {
                Log.e(TAG, "Error assigning student folders: ${e.message}", e)
            }
        }
    }

    fun bulkApproveStudents(studentIds: List<String>) {
        if (studentIds.isEmpty()) return
        val current = _statusOverrides.value.toMutableMap()
        studentIds.forEach { current[it] = "approved" }
        _statusOverrides.value = current
        viewModelScope.launch {
            try {
                studyRepository.bulkUpdateStudentStatus(studentIds, "approved")
            } catch (e: Exception) {
                Log.e(TAG, "Error bulk approving students: ${e.message}", e)
                val rollback = _statusOverrides.value.toMutableMap()
                studentIds.forEach { rollback.remove(it) }
                _statusOverrides.value = rollback
            }
        }
    }

    fun bulkRejectStudents(studentIds: List<String>) {
        if (studentIds.isEmpty()) return
        val current = _statusOverrides.value.toMutableMap()
        studentIds.forEach { current[it] = "rejected" }
        _statusOverrides.value = current
        viewModelScope.launch {
            try {
                studyRepository.bulkUpdateStudentStatus(studentIds, "rejected")
            } catch (e: Exception) {
                Log.e(TAG, "Error bulk rejecting students: ${e.message}", e)
                val rollback = _statusOverrides.value.toMutableMap()
                studentIds.forEach { rollback.remove(it) }
                _statusOverrides.value = rollback
            }
        }
    }

    fun rejectStudent(studentId: String) {
        _statusOverrides.value = _statusOverrides.value + (studentId to "rejected")
        viewModelScope.launch {
            try {
                studyRepository.updateUserStatus(studentId, "rejected")
            } catch (e: Exception) {
                Log.e(TAG, "Error rejecting student: ${e.message}", e)
                _statusOverrides.value = _statusOverrides.value - studentId
            }
        }
    }

    fun revokeStudent(studentId: String) {
        _statusOverrides.value = _statusOverrides.value + (studentId to "pending")
        viewModelScope.launch {
            try {
                studyRepository.updateUserStatus(studentId, "pending")
            } catch (e: Exception) {
                Log.e(TAG, "Error revoking student: ${e.message}", e)
                _statusOverrides.value = _statusOverrides.value - studentId
            }
        }
    }

    fun addAdmin(email: String, superAdminEmail: String) {
        viewModelScope.launch {
            try {
                studyRepository.addAdminByEmail(email, superAdminEmail)
            } catch (e: Exception) {
                Log.e(TAG, "Error adding admin: ${e.message}", e)
            }
        }
    }

    fun removeAdmin(adminDocId: String) {
        viewModelScope.launch {
            try {
                studyRepository.removeAdmin(adminDocId)
            } catch (e: Exception) {
                Log.e(TAG, "Error removing admin: ${e.message}", e)
            }
        }
    }

    private fun observeAdminMaterials() {
        viewModelScope.launch {
            studyRepository.observeAdminMaterials(currentUserId).collect { materials ->
                driveRepository.syncAdminMaterials(materials.map { it.toDriveFile() })
                loadFiles()
            }
        }
    }

    fun addAdminMaterial(material: com.example.data.model.AdminMaterial) {
        viewModelScope.launch {
            try {
                studyRepository.addAdminMaterial(material)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to save admin material: ${e.message}", e)
            }
        }
    }

    fun uploadMaterialWithFile(
        material: com.example.data.model.AdminMaterial,
        contentUri: Uri?,
        onComplete: (success: Boolean, message: String?) -> Unit = { _, _ -> }
    ) {
        viewModelScope.launch {
            var uploadedStoragePath: String? = null
            try {
                require(contentUri != null) { "Select the real study file before publishing it." }
                val stableFileId = material.fileId.ifBlank { material.id }.ifBlank {
                    java.util.UUID.randomUUID().toString().replace("-", "")
                }.replace(Regex("[^A-Za-z0-9_-]"), "_").take(128)
                val stableFolderId = material.folderId.ifBlank { "study_materials_root" }
                    .replace(Regex("[^A-Za-z0-9_-]"), "_").take(40)
                require(stableFileId.isNotBlank() && stableFolderId.isNotBlank()) { "A valid material and folder ID are required." }
                require(material.name.isNotBlank() && material.name.length <= 180 &&
                    !material.name.contains('/') && !material.name.contains('\\')) {
                    "The file name must be 1–180 characters and cannot contain path separators."
                }
                val uploaded = driveRepository.uploadStudyMaterial(
                    contentUri = contentUri,
                    fileId = stableFileId,
                    fileName = material.name,
                    mimeType = material.mimeType,
                    folderId = stableFolderId
                )
                uploadedStoragePath = uploaded.storagePath
                val finalMaterial = material.copy(
                    id = stableFileId,
                    fileId = stableFileId,
                    storagePath = uploaded.storagePath,
                    folderId = stableFolderId,
                    downloadUrl = "",
                    sizeBytes = uploaded.sizeBytes
                )
                try {
                    studyRepository.addAdminMaterial(finalMaterial)
                } catch (dbError: Exception) {
                    driveRepository.deleteStudyMaterial(uploaded.storagePath)
                    throw dbError
                }
                loadFiles()
                onComplete(true, null)
            } catch (e: Exception) {
                if (!uploadedStoragePath.isNullOrBlank()) {
                    try { driveRepository.deleteStudyMaterial(uploadedStoragePath) } catch (_: Exception) { }
                }
                Log.e(TAG, "Failed to upload study material", e)
                val message = e.localizedMessage ?: "The file could not be uploaded. Please try again."
                _screenState.value = _screenState.value.copy(errorMessage = message)
                onComplete(false, message)
            }
        }
    }

    fun deleteAdminMaterial(fileId: String) {
        viewModelScope.launch {
            try {
                val storagePath = studyRepository.getAdminMaterialStoragePath(fileId)
                if (!storagePath.isNullOrBlank()) driveRepository.deleteStudyMaterial(storagePath)
                studyRepository.deleteAdminMaterial(fileId)
                val file = _screenState.value.files.find { it.id == fileId }
                if (file != null) {
                    driveRepository.deleteDownloadedFile(fileId, file.name)
                    studyRepository.removeDownload(currentUserId, fileId)
                }
                driveRepository.removeMaterialFromList(fileId)
                loadFiles()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to delete admin material: ${e.message}", e)
            }
        }
    }

    fun updateAdminMaterial(fileId: String, name: String, category: String, description: String) {
        viewModelScope.launch {
            try {
                studyRepository.updateAdminMaterial(fileId, name, category, description)
                val file = _screenState.value.files.find { it.id == fileId }
                if (file != null) {
                    val updated = file.copy(
                        name = name,
                        category = category,
                        description = description
                    )
                    driveRepository.updateMaterialInCurrentFiles(updated)
                }
                loadFiles()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to update admin material: ${e.message}", e)
            }
        }
    }

    private fun observeProfile() {
        viewModelScope.launch {
            studyRepository.observeUserProfile(currentUserId).collect { profile ->
                if (profile != null) {
                    val isSuper = profile.isSuperAdmin
                    val newFolderId: String
                    val newFolderName: String

                    if (isSuper) {
                        newFolderId = profile.activeFolderId.ifBlank { "study_materials_root" }
                        newFolderName = profile.activeFolderName.ifBlank { "جميع المواد والمجلدات (الرئيسي)" }
                    } else if (profile.allowedFolderIds.isNotEmpty()) {
                        val currentActive = _screenState.value.activeFolderId
                        if (currentActive in profile.allowedFolderIds) {
                            newFolderId = currentActive
                            newFolderName = _screenState.value.activeFolderName
                        } else {
                            val firstFolderId = profile.allowedFolderIds.first()
                            val matchingFolder = subjectFolders.value.find { (it.folderId.ifBlank { it.id }) == firstFolderId }
                            newFolderId = firstFolderId
                            newFolderName = matchingFolder?.name ?: "المجلد المخصص"
                        }
                    } else {
                        newFolderId = "no_assigned_folders"
                        newFolderName = "بانتظار تخصيص المجلدات"
                    }

                    _screenState.value = _screenState.value.copy(
                        activeFolderId = newFolderId,
                        activeFolderName = newFolderName
                    )
                }
            }
        }
    }

    fun loadFiles(folderId: String? = null) {
        viewModelScope.launch {
            _screenState.value = _screenState.value.copy(isLoading = true, errorMessage = null)
            try {
                val targetFolder = folderId ?: _screenState.value.activeFolderId
                val files = driveRepository.fetchStudyFolderFiles(targetFolder)
                val storage = driveRepository.getTotalStorageUsedBytes()
                _screenState.value = _screenState.value.copy(
                    files = files,
                    isLoading = false,
                    totalStorageUsedBytes = storage
                )
            } catch (e: Exception) {
                Log.e(TAG, "Error loading study files: ${e.message}", e)
                _screenState.value = _screenState.value.copy(
                    isLoading = false,
                    errorMessage = "Failed to load study files: ${e.localizedMessage}"
                )
            }
        }
    }

    fun changeFolder(folderId: String, folderName: String) {
        viewModelScope.launch {
            val cleanId = folderId.trim()
            val cleanName = folderName.trim().ifBlank { "Study Materials" }
            _screenState.value = _screenState.value.copy(
                activeFolderId = cleanId,
                activeFolderName = cleanName
            )
            studyRepository.updateActiveFolder(currentUserId, cleanId, cleanName)
            loadFiles(cleanId)
        }
    }

    fun setSearchQuery(query: String) {
        _screenState.value = _screenState.value.copy(searchQuery = query)
    }

    fun selectCategory(category: String) {
        _screenState.value = _screenState.value.copy(selectedCategory = category)
    }

    fun selectFileType(type: String) {
        _screenState.value = _screenState.value.copy(selectedFileType = type)
    }

    fun selectSemester(semester: String) {
        _screenState.value = _screenState.value.copy(selectedSemester = semester)
    }

    fun selectAcademicYear(year: String) {
        _screenState.value = _screenState.value.copy(selectedAcademicYear = year)
    }

    fun selectProfessor(prof: String) {
        _screenState.value = _screenState.value.copy(selectedProfessor = prof)
    }

    fun selectCourse(course: String) {
        _screenState.value = _screenState.value.copy(selectedCourse = course)
    }

    fun selectDepartment(dept: String) {
        _screenState.value = _screenState.value.copy(selectedDepartment = dept)
    }

    fun clearAllFilters() {
        _screenState.value = _screenState.value.copy(
            searchQuery = "",
            selectedCategory = "All",
            selectedFileType = "All",
            selectedSemester = "All",
            selectedAcademicYear = "All",
            selectedProfessor = "All",
            selectedCourse = "All",
            selectedDepartment = "All"
        )
    }

    fun postAnnouncement(title: String, content: String, author: String = "Academic Administration", type: String = "general", isPinned: Boolean = true) {
        viewModelScope.launch {
            try {
                val announcement = StudyAnnouncement(
                    title = title,
                    content = content,
                    author = author,
                    type = type,
                    date = "الآن",
                    isPinned = isPinned
                )
                studyRepository.addAnnouncement(announcement)
            } catch (e: Exception) {
                Log.e(TAG, "Error posting announcement: ${e.message}", e)
            }
        }
    }

    fun deleteAnnouncement(id: String) {
        viewModelScope.launch {
            try {
                studyRepository.deleteAnnouncement(id)
            } catch (e: Exception) {
                Log.e(TAG, "Error deleting announcement: ${e.message}", e)
            }
        }
    }

    fun clearCache(): Long {
        val freedBytes = driveRepository.clearLocalCache()
        viewModelScope.launch {
            loadFiles()
            _screenState.value = _screenState.value.copy(
                totalStorageUsedBytes = 0L
            )
        }
        return freedBytes
    }

    suspend fun getPreviewFile(file: DriveFile): File {
        return driveRepository.getOrGeneratePreviewFile(file)
    }

    fun downloadFile(file: DriveFile) {
        viewModelScope.launch {
            val currentMap = _screenState.value.downloadProgress.toMutableMap()
            currentMap[file.id] = 0.05f
            _screenState.value = _screenState.value.copy(downloadProgress = currentMap)

            try {
                val downloadedLocalFile = driveRepository.downloadFile(file) { progress ->
                    val map = _screenState.value.downloadProgress.toMutableMap()
                    map[file.id] = progress
                    _screenState.value = _screenState.value.copy(downloadProgress = map)
                }

                // Record download in Firestore
                studyRepository.recordDownload(
                    userId = currentUserId,
                    download = DownloadedFile(
                        id = file.id,
                        fileId = file.id,
                        fileName = file.name,
                        mimeType = file.mimeType,
                        fileSizeBytes = downloadedLocalFile.length(),
                        localFilePath = downloadedLocalFile.absolutePath,
                        userId = currentUserId
                    )
                )

                // Refresh files state
                loadFiles()

                val finalMap = _screenState.value.downloadProgress.toMutableMap()
                finalMap.remove(file.id)
                _screenState.value = _screenState.value.copy(
                    downloadProgress = finalMap,
                    totalStorageUsedBytes = driveRepository.getTotalStorageUsedBytes()
                )
            } catch (e: Exception) {
                Log.e(TAG, "Download failed for ${file.name}: ${e.message}", e)
                val finalMap = _screenState.value.downloadProgress.toMutableMap()
                finalMap.remove(file.id)
                _screenState.value = _screenState.value.copy(
                    downloadProgress = finalMap,
                    errorMessage = "Failed to download ${file.name}"
                )
            }
        }
    }

    fun deleteDownloadedFile(fileId: String, fileName: String) {
        viewModelScope.launch {
            try {
                driveRepository.deleteDownloadedFile(fileId, fileName)
                studyRepository.removeDownload(currentUserId, fileId)
                loadFiles()
                _screenState.value = _screenState.value.copy(
                    totalStorageUsedBytes = driveRepository.getTotalStorageUsedBytes()
                )
            } catch (e: Exception) {
                Log.e(TAG, "Error deleting local file: ${e.message}", e)
            }
        }
    }

    fun toggleBookmark(file: DriveFile, notes: String = "") {
        viewModelScope.launch {
            val isBookmarked = bookmarks.value.any { it.fileId == file.id }
            try {
                if (isBookmarked) {
                    studyRepository.removeBookmark(currentUserId, file.id)
                } else {
                    studyRepository.addBookmark(
                        currentUserId,
                        StudyBookmark(
                            id = file.id,
                            fileId = file.id,
                            fileName = file.name,
                            mimeType = file.mimeType,
                            notes = notes,
                            category = file.category,
                            userId = currentUserId
                        )
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error toggling bookmark: ${e.message}", e)
            }
        }
    }

    fun updateBookmarkNotes(fileId: String, fileName: String, mimeType: String, notes: String) {
        viewModelScope.launch {
            try {
                studyRepository.addBookmark(
                    currentUserId,
                    StudyBookmark(
                        id = fileId,
                        fileId = fileId,
                        fileName = fileName,
                        mimeType = mimeType,
                        notes = notes,
                        userId = currentUserId
                    )
                )
            } catch (e: Exception) {
                Log.e(TAG, "Error updating bookmark notes: ${e.message}", e)
            }
        }
    }

    fun openFileExternal(context: Context, file: DriveFile) {
        try {
            // Resolve local files from the UID-scoped private cache; ignore legacy paths from Firestore.
            val fileObj = driveRepository.getCachedFile(file.name)
            if (fileObj != null) {
                val uri: Uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    fileObj
                )
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, file.mimeType.ifBlank { "*/*" })
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(Intent.createChooser(intent, "Open with"))
            } else if (com.example.security.SafeUrl.toSafeUri(file.webViewLink) != null) {
                val intent = Intent(Intent.ACTION_VIEW, com.example.security.SafeUrl.toSafeUri(file.webViewLink)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } else {
                Toast.makeText(context, "Download file first to open locally", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open file: ${e.message}", e)
            Toast.makeText(context, "No app found to open this file type", Toast.LENGTH_LONG).show()
        }
    }

    fun shareFile(context: Context, file: DriveFile) {
        try {
            // Resolve local files from the UID-scoped private cache; ignore legacy paths from Firestore.
            val fileObj = driveRepository.getCachedFile(file.name)
            if (fileObj != null) {
                val uri: Uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    fileObj
                )
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = file.mimeType.ifBlank { "*/*" }
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_SUBJECT, file.name)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, "Share Study Material"))
            } else {
                val shareText = buildString {
                    append("Study Material: ${file.name}")
                    com.example.security.SafeUrl.toSafeUri(file.webViewLink)?.let { append("\n$it") }
                    else append("\nOpen StudyDrive and sign in to access this protected material.")
                }
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, shareText)
                    putExtra(Intent.EXTRA_SUBJECT, file.name)
                }
                context.startActivity(Intent.createChooser(intent, "Share Study Link"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to share file: ${e.message}", e)
            Toast.makeText(context, "Error sharing file: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun getLocalPreviewText(fileName: String): String? {
        return driveRepository.getLocalFileContent(fileName)
    }
}

package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.data.model.DriveFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.tasks.await
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageMetadata
import com.google.firebase.storage.StorageException
import java.io.IOException
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class DriveRepository(private val context: Context, userId: String) {

    companion object {
        private const val TAG = "DriveRepository"
        private const val DRIVE_API_BASE = "https://www.googleapis.com/drive/v3"
        private const val MAX_MATERIAL_SIZE_BYTES = 50L * 1024L * 1024L
    }

    private val httpClient = OkHttpClient.Builder().build()
    private val downloadsRoot = File(context.filesDir, "downloads").apply { if (!exists()) mkdirs() }
    private val userCacheKey = userId.replace(Regex("[^A-Za-z0-9_-]"), "_").take(128).ifBlank { "anonymous" }
    private val downloadsDir = File(downloadsRoot, userCacheKey).apply { if (!exists()) mkdirs() }

    init {
        // Remove old shared-cache files created before caches became user-scoped. These are
        // downloadable copies, not source records; they can be fetched again after sign-in.
        downloadsRoot.listFiles()?.filter { it.isFile }?.forEach { legacyFile ->
            if (!legacyFile.delete()) Log.w(TAG, "Could not remove legacy shared cache file")
        }
    }

    // Official study materials for "بوابة البرمجة للبكالوريا - المهندس أحمد عثمان"
    // Production content is loaded from Firestore and Cloud Storage; no synthetic files are seeded.
    private val initialSampleMaterials = emptyList<DriveFile>()

    private val _currentFiles = MutableStateFlow<List<DriveFile>>(initialSampleMaterials)
    val currentFiles: Flow<List<DriveFile>> = _currentFiles.asStateFlow()

    fun syncAdminMaterials(adminList: List<DriveFile>) {
        val baseList = initialSampleMaterials.toMutableList()
        for (item in adminList) {
            val idx = baseList.indexOfFirst { it.id == item.id }
            if (idx >= 0) {
                baseList[idx] = item
            } else {
                baseList.add(0, item)
            }
        }
        val updated = baseList.map { file ->
            val local = getCachedFile(file.name)
            file.copy(
                isDownloaded = local != null,
                localFilePath = local?.absolutePath
            )
        }
        _currentFiles.value = updated
    }

    suspend fun fetchStudyFolderFiles(
        folderId: String = "study_materials_root",
        accessToken: String? = null
    ): List<DriveFile> = withContext(Dispatchers.IO) {
        if (!accessToken.isNullOrBlank() && folderId != "study_materials_root") {
            try {
                val query = "'$folderId' in parents and trashed = false"
                val url = "$DRIVE_API_BASE/files?q=${query}&fields=files(id,name,mimeType,size,modifiedTime,webViewLink,webContentLink,thumbnailLink)&orderBy=folder,name"
                val request = Request.Builder()
                    .url(url)
                    .addHeader("Authorization", "Bearer $accessToken")
                    .build()

                val response = httpClient.newCall(request).execute()
                if (response.isSuccessful) {
                    val responseBody = response.body?.string().orEmpty()
                    val json = JSONObject(responseBody)
                    val filesArray = json.optJSONArray("files")
                    if (filesArray != null) {
                        val parsedFiles = mutableListOf<DriveFile>()
                        for (i in 0 until filesArray.length()) {
                            val item = filesArray.getJSONObject(i)
                            val fId = item.optString("id")
                            val fName = item.optString("name")
                            val fMime = item.optString("mimeType")
                            val fSize = item.optLong("size", 0L)
                            val fMod = item.optString("modifiedTime")
                            val fWeb = item.optString("webViewLink")
                            val fContent = item.optString("webContentLink")
                            val fThumb = item.optString("thumbnailLink")

                            val localFile = File(downloadsDir, safeFileName(fName))
                            parsedFiles.add(
                                DriveFile(
                                    id = fId,
                                    name = fName,
                                    mimeType = fMime,
                                    sizeBytes = fSize,
                                    modifiedTime = fMod,
                                    webViewLink = fWeb,
                                    webContentLink = fContent,
                                    thumbnailLink = fThumb,
                                    parentFolderId = folderId,
                                    category = inferCategory(fName),
                                    isDownloaded = localFile.exists(),
                                    localFilePath = if (localFile.exists()) localFile.absolutePath else null
                                )
                            )
                        }
                        _currentFiles.value = parsedFiles
                        return@withContext parsedFiles
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Drive API query failed, falling back to local study folder: ${e.message}")
            }
        }

        val updated = _currentFiles.value.map { file ->
            val local = File(downloadsDir, safeFileName(file.name))
            file.copy(
                isDownloaded = local.exists(),
                localFilePath = if (local.exists()) local.absolutePath else null
            )
        }
        _currentFiles.value = updated
        updated
    }

    private fun inferCategory(name: String): String {
        val lower = name.lowercase()
        return when {
            lower.contains("بايثون") || lower.contains("python") -> "Python"
            lower.contains("خوارزم") || lower.contains("algorithm") || lower.contains("تدفق") || lower.contains("flow") -> "Algorithms"
            lower.contains("امتحان") || lower.contains("exam") || lower.contains("أسئلة") || lower.contains("test") -> "Past Exams"
            lower.contains("ويب") || lower.contains("html") || lower.contains("css") || lower.contains("web") -> "Web Development"
            lower.contains("c++") || lower.contains("سي") -> "C++"
            else -> "Programming"
        }
    }

    suspend fun uploadStudyMaterial(
        contentUri: Uri,
        fileId: String,
        fileName: String,
        mimeType: String,
        folderId: String
    ): UploadedStudyMaterial = withContext(Dispatchers.IO) {
        require(fileId.isNotBlank()) { "A material ID is required" }
        val safeId = fileId.replace(Regex("[^A-Za-z0-9_-]"), "_").take(128)
        val safeFolderId = folderId.replace(Regex("[^A-Za-z0-9_-]"), "_").take(40)
        require(safeId.isNotBlank() && safeFolderId.isNotBlank()) { "Invalid material or folder ID" }
        val safeName = safeFileName(fileName)
        val storagePath = "materials/$safeFolderId/$safeId/$safeName"
        val input = context.contentResolver.openInputStream(contentUri)
            ?: throw IOException("The selected file could not be opened")
        try {
            val metadata = StorageMetadata.Builder()
                .setContentType(mimeType.ifBlank { "application/octet-stream" })
                .build()
            val reference = FirebaseStorage.getInstance().reference.child(storagePath)
            input.use { stream -> reference.putStream(stream, metadata).await() }
            val uploadedMetadata = reference.metadata.await()
            if (uploadedMetadata.sizeBytes <= 0L || uploadedMetadata.sizeBytes > MAX_MATERIAL_SIZE_BYTES) {
                reference.delete().await()
                throw IOException("The uploaded file must be between 1 byte and 50 MiB")
            }
            UploadedStudyMaterial(storagePath = storagePath, sizeBytes = uploadedMetadata.sizeBytes)
        } catch (e: Exception) {
            Log.e(TAG, "Cloud upload failed for $safeId", e)
            throw e
        }
    }

    suspend fun deleteStudyMaterial(storagePath: String) = withContext(Dispatchers.IO) {
        if (storagePath.isBlank() || storagePath.contains("..")) return@withContext
        try {
            FirebaseStorage.getInstance().reference.child(storagePath).delete().await()
        } catch (e: StorageException) {
            if (e.errorCode != StorageException.ERROR_OBJECT_NOT_FOUND) throw e
        }
    }

    suspend fun downloadFile(
        file: DriveFile,
        accessToken: String? = null,
        onProgress: (Float) -> Unit
    ): File = withContext(Dispatchers.IO) {
        val safeName = safeFileName(file.name)
        val targetFile = File(downloadsDir, safeName).canonicalFile
        val parent = downloadsDir.canonicalFile
        if (targetFile.parentFile != parent) throw IOException("Unsafe download path")
        val tempFile = File(parent, ".${safeName}.${System.nanoTime()}.part")
        try {
            if (file.storagePath.isNotBlank()) {
                val storagePath = file.storagePath
                if (!storagePath.startsWith("materials/") || storagePath.contains("..")) {
                    throw IOException("Invalid cloud storage path")
                }
                val task = FirebaseStorage.getInstance().reference.child(storagePath).getFile(tempFile)
                task.addOnProgressListener { snapshot ->
                    if (snapshot.totalByteCount > 0L) {
                        onProgress((snapshot.bytesTransferred.toFloat() / snapshot.totalByteCount.toFloat()).coerceIn(0f, 1f))
                    }
                }
                task.await()
            } else if (!accessToken.isNullOrBlank() && file.id.isNotBlank()) {
                // Existing Google Drive integration remains opt-in and requires a valid OAuth access token.
                val url = "$DRIVE_API_BASE/files/${java.net.URLEncoder.encode(file.id, "UTF-8")}?alt=media"
                val request = Request.Builder().url(url)
                    .addHeader("Authorization", "Bearer $accessToken").build()
                httpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) throw IOException("Google Drive download failed (HTTP ${response.code})")
                    val body = response.body ?: throw IOException("Google Drive returned an empty response")
                    val declaredLength = body.contentLength()
                    if (declaredLength > MAX_MATERIAL_SIZE_BYTES) throw IOException("Study files cannot exceed 50 MiB")
                    body.byteStream().use { input ->
                        FileOutputStream(tempFile).use { output ->
                            val buffer = ByteArray(16 * 1024)
                            var copied = 0L
                            while (true) {
                                val count = input.read(buffer)
                                if (count < 0) break
                                copied += count
                                if (copied > MAX_MATERIAL_SIZE_BYTES) throw IOException("Study files cannot exceed 50 MiB")
                                output.write(buffer, 0, count)
                                if (declaredLength > 0) onProgress((copied.toFloat() / declaredLength.toFloat()).coerceIn(0f, 1f))
                            }
                        }
                    }
                }
            } else {
                throw IOException("This material has no real cloud file. An administrator must upload it again.")
            }

            if (!tempFile.exists() || tempFile.length() <= 0L) throw IOException("The downloaded file is empty")
            if (tempFile.length() > MAX_MATERIAL_SIZE_BYTES) throw IOException("Study files cannot exceed 50 MiB")
            if (targetFile.exists() && !targetFile.delete()) throw IOException("Could not replace the existing local file")
            if (!tempFile.renameTo(targetFile)) {
                val finalizeTemp = File(parent, ".${safeName}.${System.nanoTime()}.finalizing")
                try {
                    tempFile.copyTo(finalizeTemp, overwrite = true)
                    if (!finalizeTemp.renameTo(targetFile)) throw IOException("Could not finalize downloaded file")
                } finally {
                    finalizeTemp.delete()
                }
                if (!tempFile.delete()) Log.w(TAG, "Could not delete temporary download file")
            }
            onProgress(1f)
            updateFileDownloadState(file.id, targetFile.absolutePath)
            targetFile
        } catch (e: Exception) {
            tempFile.delete()
            Log.e(TAG, "Download failed for ${file.name}", e)
            throw e
        }
    }

    private fun safeFileName(name: String): String {
        val leaf = name.substringAfterLast('/').substringAfterLast('\\')
        val cleaned = leaf.replace(Regex("[^\\p{L}\\p{N}._ -]"), "_")
            .trim().trim('.')
            .take(180)
        if (cleaned.isBlank() || cleaned == "." || cleaned == "..") {
            throw IOException("Invalid file name")
        }
        return cleaned
    }

    data class UploadedStudyMaterial(val storagePath: String, val sizeBytes: Long)

    suspend fun getOrGeneratePreviewFile(file: DriveFile): File = withContext(Dispatchers.IO) {
        val safeName = safeFileName(file.name)
        val targetFile = File(downloadsDir, safeName).canonicalFile
        if (targetFile.parentFile != downloadsDir.canonicalFile) throw IOException("Unsafe preview path")
        if (targetFile.exists() && targetFile.length() > 0L) return@withContext targetFile
        // Previews must display the actual study material, never metadata converted into placeholder content.
        downloadFile(file) { /* preview download does not display per-byte progress */ }
    }


    private fun updateFileDownloadState(fileId: String, localPath: String) {
        val updated = _currentFiles.value.map {
            if (it.id == fileId) {
                it.copy(isDownloaded = true, localFilePath = localPath)
            } else {
                it
            }
        }
        _currentFiles.value = updated
    }

    suspend fun deleteDownloadedFile(fileId: String, fileName: String): Boolean = withContext(Dispatchers.IO) {
        val file = File(downloadsDir, safeFileName(fileName)).canonicalFile
        if (file.parentFile != downloadsDir.canonicalFile) return@withContext false
        val deleted = if (file.exists()) file.delete() else true
        val updated = _currentFiles.value.map {
            if (it.id == fileId) {
                it.copy(isDownloaded = false, localFilePath = null)
            } else {
                it
            }
        }
        _currentFiles.value = updated
        deleted
    }

    fun getLocalFileContent(fileName: String): String? {
        val lower = fileName.lowercase()
        val isTextFile = lower.endsWith(".txt") || lower.endsWith(".md") || lower.endsWith(".py") ||
            lower.endsWith(".kt") || lower.endsWith(".java") || lower.endsWith(".c") ||
            lower.endsWith(".cpp") || lower.endsWith(".json") || lower.endsWith(".html") || lower.endsWith(".css")
        if (!isTextFile) return null
        val file = try { File(downloadsDir, safeFileName(fileName)).canonicalFile } catch (_: Exception) { return null }
        if (file.parentFile != downloadsDir.canonicalFile) return null
        return if (file.exists() && file.canRead() && file.length() <= 512 * 1024L) {
            try {
                file.readText()
            } catch (e: Exception) {
                null
            }
        } else {
            null
        }
    }

    fun updateMaterialInCurrentFiles(updatedFile: DriveFile) {
        val updated = _currentFiles.value.map {
            if (it.id == updatedFile.id) {
                val local = File(downloadsDir, safeFileName(updatedFile.name))
                updatedFile.copy(
                    isDownloaded = local.exists(),
                    localFilePath = if (local.exists()) local.absolutePath else null
                )
            } else {
                it
            }
        }
        _currentFiles.value = updated
    }

    fun removeMaterialFromList(fileId: String) {
        _currentFiles.value = _currentFiles.value.filterNot { it.id == fileId }
    }

    fun getCachedFile(fileName: String): File? {
        val file = try { File(downloadsDir, safeFileName(fileName)).canonicalFile }
        catch (_: Exception) { return null }
        if (file.parentFile != downloadsDir.canonicalFile) return null
        return file.takeIf { it.exists() && it.isFile && it.canRead() && it.length() > 0L }
    }

    fun getDownloadedFilesList(): List<File> {
        return downloadsDir.listFiles()?.filter { it.isFile }?.toList() ?: emptyList()
    }

    fun getTotalStorageUsedBytes(): Long {
        return downloadsDir.listFiles()?.filter { it.isFile }?.sumOf { it.length() } ?: 0L
    }

    fun clearLocalCache(): Long {
        val files = downloadsDir.listFiles() ?: return 0L
        var freedBytes = 0L
        for (f in files) {
            freedBytes += f.length()
            f.delete()
        }
        val updated = _currentFiles.value.map {
            it.copy(isDownloaded = false, localFilePath = null)
        }
        _currentFiles.value = updated
        return freedBytes
    }
}


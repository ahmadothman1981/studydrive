package com.example.data.repository

import android.util.Log
import com.example.data.model.AdminMaterial
import com.example.data.model.AdminUser
import com.example.data.model.DownloadedFile
import com.example.data.model.SUPER_ADMIN_EMAIL
import com.example.data.model.StudyAnnouncement
import com.example.data.model.StudyBookmark
import com.example.data.model.UserProfile
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

class StudyRepository(private val db: FirebaseFirestore) {

    private val _studentsPageSize = MutableStateFlow(100)
    val studentsPageSize: StateFlow<Int> = _studentsPageSize.asStateFlow()
    private val _materialsPageSize = MutableStateFlow(100)
    val materialsPageSize: StateFlow<Int> = _materialsPageSize.asStateFlow()

    fun loadMoreStudents() { _studentsPageSize.value += 100 }
    fun loadMoreAdminMaterials() { _materialsPageSize.value += 100 }

    companion object {
        private const val TAG = "StudyRepository"
    }

    fun observeUserProfile(userId: String): Flow<UserProfile?> {
        return db.collection("users").document(userId)
            .snapshots()
            .map { snapshot ->
                if (snapshot.exists()) {
                    snapshot.toObject(UserProfile::class.java)
                } else {
                    null
                }
            }
    }

    suspend fun getUserProfile(userId: String): UserProfile? {
        return try {
            val snapshot = db.collection("users").document(userId).get().await()
            if (snapshot.exists()) snapshot.toObject(UserProfile::class.java) else null
        } catch (e: Exception) {
            Log.e(TAG, "Error getting user profile", e)
            null
        }
    }

    suspend fun saveUserProfile(profile: UserProfile) {
        require(profile.userId.isNotBlank()) { "User ID cannot be blank" }
        try {
            db.collection("users").document(profile.userId)
                .set(profile.toMap())
                .await()
        } catch (e: Exception) {
            Log.e(TAG, "Error saving user profile: ${e.message}", e)
            throw e
        }
    }

    suspend fun updateUserStatus(userId: String, status: String) {
        require(userId.isNotBlank()) { "User ID cannot be blank" }
        try {
            db.collection("users").document(userId)
                .update(mapOf("status" to status, "updatedAt" to FieldValue.serverTimestamp()))
                .await()
        } catch (e: Exception) {
            Log.e(TAG, "Error updating user status: ${e.message}", e)
            throw e
        }
    }

    suspend fun updateStudentAllowedFolders(userId: String, allowedFolderIds: List<String>) {
        require(userId.isNotBlank()) { "User ID cannot be blank" }
        validateAssignedFolders(allowedFolderIds)
        try {
            db.collection("users").document(userId)
                .update(
                    mapOf(
                        "allowedFolderIds" to allowedFolderIds,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
        } catch (e: Exception) {
            Log.e(TAG, "Error updating student allowed folders: ${e.message}", e)
            throw e
        }
    }

    suspend fun approveStudentWithFolders(userId: String, allowedFolderIds: List<String>) {
        require(userId.isNotBlank()) { "User ID cannot be blank" }
        validateAssignedFolders(allowedFolderIds)
        try {
            db.collection("users").document(userId)
                .update(
                    mapOf(
                        "status" to "approved",
                        "allowedFolderIds" to allowedFolderIds,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
        } catch (e: Exception) {
            Log.e(TAG, "Error approving student with folders: ${e.message}", e)
            throw e
        }
    }


    private fun validateAssignedFolders(folderIds: List<String>) {
        require(folderIds.distinct().size <= 16) { "A student can be assigned up to 16 folders." }
        require(folderIds.all { it.matches(Regex("[A-Za-z0-9_-]{1,40}")) }) {
            "Folder IDs must contain only letters, numbers, underscores or hyphens and be 1–40 characters long."
        }
    }

    suspend fun updateActiveFolder(userId: String, folderId: String, folderName: String) {
        require(userId.isNotBlank()) { "User ID cannot be blank" }
        try {
            db.collection("users").document(userId)
                .update(
                    mapOf(
                        "activeFolderId" to folderId,
                        "activeFolderName" to folderName
                    )
                ).await()
        } catch (e: Exception) {
            Log.e(TAG, "Error updating active folder: ${e.message}", e)
            throw e
        }
    }

    // Super-admin-only, incrementally expandable realtime list. Pagination reduces initial reads.
    fun observeAllStudents(currentUserId: String): Flow<List<UserProfile>> {
        return observeUserProfile(currentUserId).flatMapLatest { profile ->
            if (profile?.isAdmin != true) flowOf(emptyList())
            else studentsPageSize.flatMapLatest { pageSize ->
                db.collection("users")
                    .orderBy("createdAt", Query.Direction.DESCENDING)
                    .limit(pageSize.toLong())
                    .snapshots()
                    .map { snapshot -> snapshot.toObjects(UserProfile::class.java) }
            }
        }
    }

    // Administrator documents are keyed by Firebase Auth UID and visible only to super-admin.
    fun observeAdmins(currentUserId: String): Flow<List<AdminUser>> {
        return observeUserProfile(currentUserId).flatMapLatest { profile ->
            if (profile?.isSuperAdmin != true) flowOf(emptyList())
            else db.collection("admins").snapshots().map { snapshot ->
                snapshot.toObjects(AdminUser::class.java).sortedByDescending { it.createdAt }
            }
        }
    }

    suspend fun addAdminByEmail(email: String, superAdminEmail: String) {
        require(email.isNotBlank()) { "Admin email cannot be blank" }
        val cleanEmail = email.trim().lowercase()
        require(cleanEmail.contains("@") && cleanEmail.length <= 254) { "Enter a valid email address" }
        require(!cleanEmail.equals(superAdminEmail.trim(), ignoreCase = true)) { "The super administrator cannot be invited as a regular admin" }
        try {
            db.collection("admin_invites").document(cleanEmail)
                .set(mapOf(
                    "email" to cleanEmail,
                    "addedBy" to superAdminEmail.trim().lowercase(),
                    "role" to "admin",
                    "createdAt" to FieldValue.serverTimestamp()
                )).await()
        } catch (e: Exception) {
            Log.e(TAG, "Error creating administrator invitation", e)
            throw e
        }
    }

    suspend fun acceptAdminInviteIfPresent(userId: String, email: String, addedBy: String): Boolean {
        require(userId.isNotBlank() && email.isNotBlank()) { "A signed-in UID and email are required" }
        val cleanEmail = email.trim().lowercase()
        try {
            val inviteRef = db.collection("admin_invites").document(cleanEmail)
            val invite = inviteRef.get().await()
            if (!invite.exists()) return false
            val adminRef = db.collection("admins").document(userId)
            adminRef.set(AdminUser(
                id = userId,
                email = cleanEmail,
                addedBy = invite.getString("addedBy") ?: addedBy,
                role = "admin"
            ).toMap()).await()
            // A successful invitation is consumed. The backend rules only permit the invitee
            // to remove their own invite after their UID-based admin record exists.
            inviteRef.delete().await()
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Error accepting administrator invitation", e)
            throw e
        }
    }

    suspend fun isAdminUid(userId: String): Boolean {
        if (userId.isBlank()) return false
        return try { db.collection("admins").document(userId).get().await().exists() }
        catch (e: Exception) { Log.w(TAG, "Could not verify admin UID", e); false }
    }

    suspend fun removeAdmin(adminDocId: String) {
        require(adminDocId.isNotBlank()) { "Admin ID cannot be blank" }
        try {
            val adminRef = db.collection("admins").document(adminDocId)
            val adminSnapshot = adminRef.get().await()
            val email = adminSnapshot.getString("email")?.trim()?.lowercase()
            val batch = db.batch()
            batch.delete(adminRef)
            if (!email.isNullOrBlank()) batch.delete(db.collection("admin_invites").document(email))
            batch.commit().await()
        } catch (e: Exception) {
            Log.e(TAG, "Error removing administrator", e)
            throw e
        }
    }

    fun observeDownloads(userId: String): Flow<List<DownloadedFile>> {
        return db.collection("users").document(userId)
            .collection("downloads")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(DownloadedFile::class.java)
                    .sortedByDescending { it.downloadedAt }
            }
    }

    suspend fun recordDownload(userId: String, download: DownloadedFile) {
        require(userId.isNotBlank()) { "User ID cannot be blank" }
        require(download.fileId.isNotBlank()) { "File ID cannot be blank" }
        try {
            db.collection("users").document(userId)
                .collection("downloads")
                .document(download.fileId)
                .set(download.toMap())
                .await()
        } catch (e: Exception) {
            Log.e(TAG, "Error recording download: ${e.message}", e)
            throw e
        }
    }

    suspend fun removeDownload(userId: String, fileId: String) {
        require(userId.isNotBlank()) { "User ID cannot be blank" }
        try {
            db.collection("users").document(userId)
                .collection("downloads")
                .document(fileId)
                .delete()
                .await()
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting download record: ${e.message}", e)
            throw e
        }
    }

    fun observeBookmarks(userId: String): Flow<List<StudyBookmark>> {
        return db.collection("users").document(userId)
            .collection("bookmarks")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(StudyBookmark::class.java)
                    .sortedByDescending { it.createdAt }
            }
    }

    suspend fun addBookmark(userId: String, bookmark: StudyBookmark) {
        require(userId.isNotBlank()) { "User ID cannot be blank" }
        require(bookmark.fileId.isNotBlank()) { "File ID cannot be blank" }
        try {
            db.collection("users").document(userId)
                .collection("bookmarks")
                .document(bookmark.fileId)
                .set(bookmark.toMap())
                .await()
        } catch (e: Exception) {
            Log.e(TAG, "Error adding bookmark: ${e.message}", e)
            throw e
        }
    }

    suspend fun removeBookmark(userId: String, fileId: String) {
        require(userId.isNotBlank()) { "User ID cannot be blank" }
        try {
            db.collection("users").document(userId)
                .collection("bookmarks")
                .document(fileId)
                .delete()
                .await()
        } catch (e: Exception) {
            Log.e(TAG, "Error removing bookmark: ${e.message}", e)
            throw e
        }
    }

    // Material collection streams expand in 100-record steps. Student queries remain folder-constrained.
    fun observeAdminMaterials(userId: String): Flow<List<AdminMaterial>> {
        return observeUserProfile(userId).flatMapLatest { profile ->
            if (profile == null || (profile.status != "approved" && !profile.isAdmin)) {
                flowOf(emptyList())
            } else {
                materialsPageSize.flatMapLatest { pageSize ->
                    if (profile.isAdmin) {
                        db.collection("admin_materials")
                            .orderBy("createdAt", Query.Direction.DESCENDING)
                            .limit(pageSize.toLong())
                            .snapshots().map { snapshot -> snapshot.toObjects(AdminMaterial::class.java) }
                    } else {
                        val ids = profile.allowedFolderIds.filter { it.isNotBlank() }.distinct().take(16)
                        if (ids.isEmpty()) flowOf(emptyList())
                        else {
                            val flows = ids.chunked(10).map { chunk ->
                                db.collection("admin_materials").whereIn("folderId", chunk)
                                    .limit(pageSize.toLong())
                                    .snapshots().map { snapshot -> snapshot.toObjects(AdminMaterial::class.java) }
                            }
                            combine(flows) { lists ->
                                lists.flatMap { it }.distinctBy { it.fileId.ifBlank { it.id } }
                                    .sortedByDescending { it.createdAt }
                            }
                        }
                    }
                }
            }
        }
    }

    suspend fun addAdminMaterial(material: AdminMaterial) {
        require(material.fileId.isNotBlank()) { "File ID cannot be blank" }
        try {
            db.collection("admin_materials")
                .document(material.fileId)
                .set(material.toMap())
                .await()
        } catch (e: Exception) {
            Log.e(TAG, "Error saving admin material: ${e.message}", e)
            throw e
        }
    }

    suspend fun updateAdminMaterial(fileId: String, name: String, category: String, description: String) {
        require(fileId.isNotBlank()) { "File ID cannot be blank" }
        try {
            val docRef = db.collection("admin_materials").document(fileId)
            val snapshot = docRef.get().await()
            if (snapshot.exists()) {
                val updates = mutableMapOf<String, Any>(
                    "name" to name.trim(),
                    "category" to category.trim(),
                    "description" to description.trim()
                )
                docRef.update(updates).await()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error updating admin material: ${e.message}", e)
            throw e
        }
    }

    suspend fun getAdminMaterialStoragePath(fileId: String): String? {
        require(fileId.isNotBlank()) { "File ID cannot be blank" }
        val snapshot = db.collection("admin_materials").document(fileId).get().await()
        return if (snapshot.exists()) snapshot.getString("storagePath") else null
    }

    suspend fun deleteAdminMaterial(fileId: String) {
        require(fileId.isNotBlank()) { "File ID cannot be blank" }
        try {
            db.collection("admin_materials").document(fileId).delete().await()
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting admin material", e)
            throw e
        }
    }

    suspend fun bulkUpdateStudentStatus(studentIds: List<String>, status: String) {
        if (studentIds.isEmpty()) return
        val batch = db.batch()
        for (id in studentIds) {
            val docRef = db.collection("users").document(id)
            batch.update(docRef, mapOf("status" to status, "updatedAt" to FieldValue.serverTimestamp()))
        }
        try {
            batch.commit().await()
        } catch (e: Exception) {
            Log.e(TAG, "Error in bulk updating student status: ${e.message}", e)
            throw e
        }
    }

    fun observeAnnouncements(userId: String): Flow<List<StudyAnnouncement>> {
        return observeUserProfile(userId).flatMapLatest { profile ->
            if (profile == null || (profile.status != "approved" && !profile.isAdmin)) flowOf(emptyList())
            else db.collection("announcements").snapshots().map { snapshot ->
                snapshot.toObjects(StudyAnnouncement::class.java).sortedByDescending { it.createdAt }
            }
        }
    }

    suspend fun addAnnouncement(announcement: StudyAnnouncement) {
        try {
            val docRef = if (announcement.id.isNotBlank()) {
                db.collection("announcements").document(announcement.id)
            } else {
                db.collection("announcements").document()
            }
            docRef.set(announcement.toMap()).await()
        } catch (e: Exception) {
            Log.e(TAG, "Error adding announcement: ${e.message}", e)
            throw e
        }
    }

    suspend fun deleteAnnouncement(id: String) {
        try {
            db.collection("announcements").document(id).delete().await()
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting announcement: ${e.message}", e)
            throw e
        }
    }

    // Folder queries are restricted server-side to the folders assigned to the signed-in student.
    fun observeSubjectFolders(userId: String): Flow<List<com.example.data.model.SubjectFolder>> {
        return observeUserProfile(userId).flatMapLatest { profile ->
            if (profile == null || (profile.status != "approved" && !profile.isAdmin)) {
                flowOf(emptyList())
            } else if (profile.isAdmin) {
                db.collection("subject_folders").snapshots().map { snapshot ->
                    snapshot.toObjects(com.example.data.model.SubjectFolder::class.java).sortedByDescending { it.createdAt }
                }
            } else {
                val ids = profile.allowedFolderIds.filter { it.isNotBlank() }.distinct().take(16)
                if (ids.isEmpty()) flowOf(emptyList())
                else {
                    val flows = ids.chunked(10).map { chunk ->
                        db.collection("subject_folders").whereIn("folderId", chunk).snapshots().map { snapshot ->
                            snapshot.toObjects(com.example.data.model.SubjectFolder::class.java)
                        }
                    }
                    combine(flows) { lists -> lists.flatMap { it }.distinctBy { it.folderId.ifBlank { it.id } }
                        .sortedByDescending { it.createdAt }
                    }
                }
            }
        }
    }

    suspend fun saveSubjectFolder(folder: com.example.data.model.SubjectFolder) {
        val docId = folder.folderId.ifBlank { folder.id }.ifBlank { "folder_${System.currentTimeMillis()}" }
        try {
            db.collection("subject_folders")
                .document(docId)
                .set(folder.copy(id = docId, folderId = docId).toMap())
                .await()
        } catch (e: Exception) {
            Log.e(TAG, "Error saving subject folder: ${e.message}", e)
            throw e
        }
    }

    suspend fun updateSubjectFolder(folder: com.example.data.model.SubjectFolder) {
        val docId = folder.folderId.ifBlank { folder.id }
        require(docId.isNotBlank()) { "Folder ID cannot be blank" }
        try {
            val docRef = db.collection("subject_folders").document(docId)
            val snapshot = docRef.get().await()
            if (snapshot.exists()) {
                val updates = mutableMapOf<String, Any>(
                    "name" to folder.name,
                    "subject" to folder.subject,
                    "department" to folder.department,
                    "grade" to folder.grade,
                    "description" to folder.description,
                    "driveFolderUrl" to folder.driveFolderUrl
                )
                docRef.update(updates).await()
            } else {
                docRef.set(folder.copy(id = docId, folderId = docId).toMap()).await()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error updating subject folder: ${e.message}", e)
            throw e
        }
    }

    suspend fun deleteSubjectFolder(folderId: String) {
        require(folderId.isNotBlank()) { "Folder ID cannot be blank" }
        try {
            db.collection("subject_folders")
                .document(folderId)
                .delete()
                .await()
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting subject folder: ${e.message}", e)
            throw e
        }
    }
}




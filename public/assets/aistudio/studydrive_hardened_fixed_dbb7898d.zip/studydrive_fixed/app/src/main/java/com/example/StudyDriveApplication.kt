package com.example

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck

/** Initializes App Check before any Firebase product is accessed. */
class StudyDriveApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
        AppCheckProviderSetup.install(FirebaseAppCheck.getInstance())
    }
}

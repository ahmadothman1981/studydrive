# ---- StudyDrive ProGuard / R8 configuration ----
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-keepattributes Signature,*Annotation*,InnerClasses,EnclosingMethod

# Firestore maps documents to these classes by reflection (toObject / toObjects)
-keep class com.example.data.model.** { *; }
-keepclassmembers class com.example.data.model.** { *; }

# Keep Firebase & Google Play Services classes
-keep class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**

# Moshi / Retrofit / OkHttp
-keepclassmembers class * {
    @com.squareup.moshi.* <fields>;
}
-keep @com.squareup.moshi.JsonClass class * { *; }
-dontwarn okhttp3.**
-dontwarn okio.**

# Strip verbose/debug/info/warn/error android.util.Log calls in release builds
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
    public static int i(...);
    public static int w(...);
    public static int e(...);
}

import { applicationDefault, getApp, initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { FieldValue, getFirestore } from 'firebase-admin/firestore';

const DATABASE_ID = process.env.FIRESTORE_DATABASE_ID || 'ai-studio-android-studydri-4fccda60-1772-4693-8315-5a866d5b0742';
const email = (process.env.SUPER_ADMIN_EMAIL || '').trim().toLowerCase();
if (!email || !email.includes('@')) {
  console.error('Set SUPER_ADMIN_EMAIL to the existing Firebase Authentication email for the super administrator.');
  process.exit(2);
}
if (!process.env.GOOGLE_APPLICATION_CREDENTIALS) {
  console.error('Set GOOGLE_APPLICATION_CREDENTIALS to a service-account JSON file outside this project folder.');
  process.exit(2);
}

initializeApp({ credential: applicationDefault() });
const auth = getAuth();
const db = getFirestore(getApp(), DATABASE_ID);

try {
  const user = await auth.getUserByEmail(email);
  const existingClaims = user.customClaims || {};
  await auth.setCustomUserClaims(user.uid, {
    ...existingClaims,
    super_admin: true,
    admin: true,
    approved: true,
  });

  await db.collection('users').doc(user.uid).set({
    userId: user.uid,
    displayName: user.displayName || 'المهندس أحمد عثمان',
    email: user.email || email,
    status: 'approved',
    role: 'super_admin',
    activeFolderId: 'study_materials_root',
    activeFolderName: 'بوابة البرمجة للبكالوريا',
    allowedFolderIds: [],
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  }, { merge: true });

  console.log(`Assigned super_admin custom claim and synced Firestore profile for UID ${user.uid}.`);
  console.log('Sign out and sign back in to refresh the ID token. Never distribute the service-account JSON or this script with credentials.');
} catch (error) {
  console.error(`Could not assign the claim: ${error.message}`);
  process.exitCode = 1;
}

import { createHash } from 'node:crypto';
import { getApp, initializeApp } from 'firebase-admin/app';
import { FieldValue, getFirestore } from 'firebase-admin/firestore';
import { getAuth } from 'firebase-admin/auth';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { onDocumentCreated, onDocumentWritten } from 'firebase-functions/v2/firestore';
import { logger, setGlobalOptions } from 'firebase-functions/v2';

initializeApp();
setGlobalOptions({ region: 'us-central1', maxInstances: 10 });

const DATABASE_ID = 'ai-studio-android-studydri-4fccda60-1772-4693-8315-5a866d5b0742';
const db = getFirestore(getApp(), DATABASE_ID);
const auth = getAuth();
const MAX_ASSIGNED_FOLDERS = 16;
const MAX_CUSTOM_CLAIMS_BYTES = 900;

const lastSyncByUid = new Map();
const SYNC_COOLDOWN_MS = 5_000;

function cleanFolderIds(value) {
  if (!Array.isArray(value)) return [];
  return [...new Set(value.filter((id) => typeof id === 'string' && /^[A-Za-z0-9_-]{1,40}$/.test(id)))].slice(0, MAX_ASSIGNED_FOLDERS);
}

async function syncClaimsForUid(uid) {
  if (!uid) return;
  let userRecord;
  try {
    userRecord = await auth.getUser(uid);
  } catch (error) {
    if (error?.code === 'auth/user-not-found') {
      logger.info('Skipping access-claim sync for a deleted Auth user', { uid });
      return;
    }
    throw error;
  }
  const [profileSnapshot, adminSnapshot] = await Promise.all([
    db.collection('users').doc(uid).get(),
    db.collection('admins').doc(uid).get(),
  ]);

  const existing = userRecord.customClaims || {};
  const isSuperAdmin = existing.super_admin === true;
  const isAdmin = isSuperAdmin || adminSnapshot.exists;
  const profile = profileSnapshot.exists ? profileSnapshot.data() : {};
  const isApproved = isAdmin || profile.status === 'approved';
  const allowedFolderIds = !isAdmin && isApproved
    ? cleanFolderIds(profile.allowedFolderIds)
    : [];

  const claims = {
    ...existing,
    admin: isAdmin,
    approved: isApproved,
    allowed_folder_ids: allowedFolderIds,
  };
  const serializedSize = Buffer.byteLength(JSON.stringify(claims), 'utf8');
  if (serializedSize > MAX_CUSTOM_CLAIMS_BYTES) {
    logger.error('Custom claims exceed the safe size budget', { uid, serializedSize });
    throw new Error(`Custom claims exceed safe size budget (${serializedSize} bytes). Reduce assigned folder IDs or unrelated custom claims.`);
  }

  await auth.setCustomUserClaims(uid, claims);
  logger.info('Synchronized access claims', {
    uid,
    admin: isAdmin,
    approved: isApproved,
    assignedFolderCount: allowedFolderIds.length,
  });
}

export const syncMyAccessClaims = onCall(async (request) => {
  const uid = request.auth?.uid;
  if (!uid) throw new HttpsError('unauthenticated', 'Sign in before synchronizing access.');

  const now = Date.now();
  const prev = lastSyncByUid.get(uid) || 0;
  if (now - prev < SYNC_COOLDOWN_MS) {
    return { ok: true, throttled: true };
  }
  lastSyncByUid.set(uid, now);

  await syncClaimsForUid(uid);
  return { ok: true };
});

export const syncUserAccessClaims = onDocumentWritten(
  { document: 'users/{userId}', database: DATABASE_ID },
  async (event) => {
    const uid = event.params.userId;
    try {
      await syncClaimsForUid(uid);
    } catch (error) {
      logger.error('Failed to synchronize claims after user profile change', { uid, error: String(error) });
      throw error;
    }
  },
);

export const syncAdminAccessClaims = onDocumentWritten(
  { document: 'admins/{adminUid}', database: DATABASE_ID },
  async (event) => {
    const uid = event.params.adminUid;
    try {
      if (!event.data?.after?.exists) {
        const profileRef = db.collection('users').doc(uid);
        const profile = await profileRef.get();
        if (profile.exists && profile.get('role') === 'admin') {
          await profileRef.update({
            role: 'student',
            status: 'pending',
            allowedFolderIds: [],
            updatedAt: FieldValue.serverTimestamp(),
          });
        }
      }
      await syncClaimsForUid(uid);
    } catch (error) {
      logger.error('Failed to synchronize claims after administrator change', { uid, error: String(error) });
      throw error;
    }
  },
);

export const incrementMaterialDownloadCount = onDocumentCreated(
  { document: 'users/{userId}/downloads/{downloadId}', database: DATABASE_ID },
  async (event) => {
    const downloadId = event.params.downloadId;
    if (!downloadId || !/^[A-Za-z0-9_-]{1,128}$/.test(downloadId)) return;
    try {
      const materialRef = db.collection('admin_materials').doc(downloadId);
      const snap = await materialRef.get();
      if (snap.exists) {
        await materialRef.update({
          downloadCount: FieldValue.increment(1),
        });
      }
    } catch (error) {
      logger.warn('Could not increment downloadCount for material', { downloadId, error: String(error) });
    }
  },
);

function sha256(value) {
  return createHash('sha256').update(value).digest('hex').slice(0, 24);
}

function changedFields(before, after) {
  const beforeObj = before && typeof before === 'object' ? before : {};
  const afterObj = after && typeof after === 'object' ? after : {};
  return [...new Set([...Object.keys(beforeObj), ...Object.keys(afterObj)])]
    .filter((key) => JSON.stringify(beforeObj[key]) !== JSON.stringify(afterObj[key]))
    .sort()
    .slice(0, 40);
}

function auditTrigger(collection) {
  return onDocumentWritten(
    { document: `${collection}/{documentId}`, database: DATABASE_ID },
    async (event) => {
      const before = event.data?.before?.data() || null;
      const after = event.data?.after?.data() || null;
      const operation = !before ? 'create' : (!after ? 'delete' : 'update');
      const documentId = event.params.documentId;
      await db.collection('admin_audit_logs').add({
        collection,
        operation,
        subjectIdHash: sha256(`${collection}/${documentId}`),
        actorUid: typeof event.authId === 'string' ? event.authId : null,
        actorType: typeof event.authType === 'string' ? event.authType : 'unknown',
        changedFields: changedFields(before, after),
        occurredAt: FieldValue.serverTimestamp(),
      });
    },
  );
}

export const auditUserChanges = auditTrigger('users');
export const auditAdminChanges = auditTrigger('admins');
export const auditInviteChanges = auditTrigger('admin_invites');
export const auditMaterialChanges = auditTrigger('admin_materials');
export const auditFolderChanges = auditTrigger('subject_folders');
export const auditAnnouncementChanges = auditTrigger('announcements');

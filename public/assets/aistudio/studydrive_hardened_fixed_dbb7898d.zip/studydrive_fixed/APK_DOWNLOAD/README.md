# APK output folder

No APK is bundled in this source package. The previous APK predated the security changes and was removed to prevent accidental installation or distribution.

Build and test the updated app from Android Studio. For production, configure a private release signing keystore and validate the signed output before distribution.

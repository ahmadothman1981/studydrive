# StudyDrive — Security & Architecture Audit Summary

## Security Fixes & Enhancements Included
1. **Server-Side Per-Folder Access Control (Firestore + Cloud Storage):**
   - `admin_materials` and `subject_folders` are restricted in `firestore.rules` so approved students can only read documents whose `folderId` is in their assigned `allowedFolderIds` list (up to 16 folders).
   - `storage.rules` enforces real file-byte authorization (`materials/{folderId}/{materialId}/{fileName}`), 50 MiB upload limits, and strict MIME-type allowlisting.
   - `functions/index.js` synchronizes `super_admin`, `admin`, `approved`, and `allowed_folder_ids` custom claims from the named Firestore database (`ai-studio-android-studydri-4fccda60-1772-4693-8315-5a866d5b0742`) with per-UID cooldown throttling.
2. **Role & Privilege Escalation Protection:**
   - Students cannot self-approve, modify `role`, or edit `allowedFolderIds` on creation or update, and cannot delete their own profile to bypass a `"rejected"` status.
   - Delegated administrators are invited by verified email (`admin_invites/{email}`) and become UID-keyed records (`admins/{adminUid}`) upon sign-in.
   - Delegated administrators can view/approve/reject students and assign folders, but `firestore.rules` blocks them from promoting any account to `admin` or `super_admin`.
3. **Real Cloud Storage Uploads & Downloads (No Synthetic Placeholder Files):**
   - Uploading a material streams actual file bytes to Firebase Cloud Storage (`materials/{folderId}/{materialId}/{fileName}`) with rollback on metadata failure.
   - Downloads write to a temporary `.part` file inside a UID-scoped private directory (`filesDir/downloads/{userId}/`) with canonical path traversal checks and no device-specific absolute paths stored in Firestore.
4. **Safe External URI Validation (`SafeUrl.kt`) & Network Hardening:**
   - `SafeUrl.toSafeUri()` restricts external links to HTTPS URLs on `drive.google.com`, `docs.google.com`, and `drive.usercontent.google.com`.
   - `android:usesCleartextTraffic="false"` and `android:allowBackup="false"` with full cloud/device-transfer exclusion rules.
   - `FileProvider` exposes only `files-path` `downloads/`.
5. **App Check & Release Hardening:**
   - `StudyDriveApplication` initializes Firebase App Check (`DebugAppCheckProviderFactory` in debug, `PlayIntegrityAppCheckProviderFactory` in release).
   - `proguard-rules.pro` keeps Firestore/Moshi models and strips `android.util.Log` calls in release builds.
6. **UX & Feature Enhancements:**
   - Native PDF viewer (`DocumentViewerDialog.kt`) persists and restores the student's last-read page per document (`studydrive_reading_progress`) and safely closes file descriptors.
   - Server-side Cloud Function (`incrementMaterialDownloadCount`) atomically increments `downloadCount` on `admin_materials/{materialId}` when a student records a download.
   - Duplicate `.aistudio/` and `public/assets/` image bloat removed and `res/drawable/` banners compressed by >80%.

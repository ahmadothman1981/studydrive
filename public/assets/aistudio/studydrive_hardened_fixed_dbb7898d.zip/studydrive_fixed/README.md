# StudyDrive — hardened Android source package

This archive contains the Android/Kotlin source project plus Firestore and Cloud Storage security rules, trusted Cloud Functions, and local authorization test suites. It intentionally does **not** bundle the previous debug APK. The previous APK was built before the security changes and must not be reused.

## What changed

- Firestore reads for study materials and subject folders are restricted to administrators or approved students assigned to the matching folder.
- Student profiles cannot self-approve, grant themselves roles, or change their assigned folders.
- Administrator invitations are stored separately by verified email and become UID-keyed administrator records only after that email signs in.
- The super-administrator permission is now a server-managed Firebase Authentication custom claim (`super_admin`), not a client-editable profile field.
- Firebase App Check is initialized on app startup. Debug builds use the debug provider; release builds use Play Integrity.
- Real file bytes are uploaded to Firebase Cloud Storage under `materials/{folderId}/{materialId}/{fileName}`. Fake/placeholder download files are no longer generated.
- Storage rules limit uploads to admins, cap files at 50 MiB, restrict file types, and gate reads by server-managed approval/admin/folder claims. Cloud Functions sync those claims from the named Firestore database because Storage Rules cannot read a non-default Firestore database.
- File names and local download paths are sanitized; downloads use temporary files and fail explicitly when no real source file exists. Downloads are cached under each user’s private app directory, and device-specific absolute paths are no longer written to Firestore. Student access is limited to 16 assigned folders so claim payloads remain below Firebase Auth custom-claim size limits.
- Administrator student/material lists load the first 100 records and expand in 100-record increments, reducing initial reads for larger deployments.
- Android backup is disabled and backup-extraction rules exclude application data.
- The Gradle setup no longer relies on a private debug keystore bundled with the project. Release signing is opt-in through private environment variables.

## Required Firebase setup before rollout

### 1. Bootstrap the super-administrator claim

The configured super-admin email remains `ahmadothmanshoap1981@gmail.com` for the existing UI. The backend now trusts the `super_admin` custom claim. The account must already exist in Firebase Authentication.

Do not place a service-account JSON file in this source folder or ZIP. Store it securely outside the repository. From the project root, run:

```bash
cd scripts
npm install
export GOOGLE_APPLICATION_CREDENTIALS="/secure/path/firebase-admin-service-account.json"
export SUPER_ADMIN_EMAIL="ahmadothmanshoap1981@gmail.com"
npm run bootstrap-super-admin
cd ..
```

On Windows PowerShell, run from the project root:

```powershell
cd scripts
npm install
$env:GOOGLE_APPLICATION_CREDENTIALS="C:\secure\firebase-admin-service-account.json"
$env:SUPER_ADMIN_EMAIL="ahmadothmanshoap1981@gmail.com"
npm run bootstrap-super-admin
cd ..
```

After the claim is assigned, sign out of the app and sign back in so Firebase refreshes the ID token. Never ship the service-account file or credentials to students.

### 2. Deploy rules to the correct Firebase project

The included `firebase.json` names the Firestore database `ai-studio-android-studydri-4fccda60-1772-4693-8315-5a866d5b0742`. Confirm this is the database used by your Firebase project before deploying. The Cloud Functions use that named database ID as the source of truth for Storage custom claims. If the database ID changes, update `functions/index.js` as well as the Firestore config.

Select the intended Firebase project with the Firebase CLI and review the target before deployment:

```bash
firebase use --add
```

Back up current data and inspect legacy `admins`, `admin_materials`, and `subject_folders` records before deploying. The new rules do not grant administrator status from the old email-derived document IDs. Re-invite each legitimate administrator from the super-admin screen and have them sign in to accept the invitation; this creates the UID-keyed record. After verifying the new accounts, remove obsolete email-derived admin records.

### 3. Install and deploy trusted Cloud Functions

The `functions/` package syncs `admin`, `approved`, and `allowed_folder_ids` custom claims from the named Firestore database. It also writes a client-immutable audit trail (field names only; invite IDs are hashed) for user, administrator, invitation, material, folder, and announcement changes. The Android app calls `syncMyAccessClaims` when the current profile or access assignment changes.

```bash
cd functions
npm install
cd ..
firebase deploy --only functions,firestore:rules,storage
```

Deploy functions before enforcing Storage access. The Cloud Functions runtime needs permission to update Firebase Authentication custom claims and read/write the named Firestore database. The super-admin bootstrap step above is still required. The client stores downloaded files under a per-user private directory; pre-upgrade shared cache files are removed rather than exposed across accounts.

### 4. Turn on App Check

In Firebase Console, register the Android app with Play Integrity and configure the Play Integrity API in Google Play Console. For local debug builds, install the app, copy its App Check debug token from the developer log, and register that token in Firebase Console. Keep debug tokens private.

Start in monitoring mode, confirm real app traffic is receiving valid tokens, then enforce App Check for Cloud Firestore and Cloud Storage. Do not enable enforcement until the production app registration and Play Integrity configuration are verified.

### 5. Re-upload existing study files

Older Firestore material records may only contain placeholder Google Drive URLs or no `storagePath`. They will not be converted into fake PDFs anymore. The non-functional Google Drive folder-URL entry points have been removed from the UI because the project does not include a complete Drive OAuth-token flow. Open the admin dashboard and upload the real source file for each material again. The app writes actual bytes to Cloud Storage and saves the private `storagePath` to Firestore. Existing materials should be treated as unavailable until verified after re-upload.

Cloud Storage access requires an enabled Firebase Storage bucket and whatever billing setup your Firebase project currently requires. The rules allow files up to 50 MiB and the MIME types listed in `storage.rules`.

## Build

Open the project directory in Android Studio and allow Gradle sync to finish. Build a debug build for local testing. A new APK has **not** been built as part of this source-level patch because this environment does not have Gradle installed and the original archive lacked the Gradle wrapper scripts.

For a distributable signed release, provide a private signing keystore through environment variables; do not add it to the ZIP:

- `KEYSTORE_PATH`
- `STORE_PASSWORD`
- `KEY_PASSWORD`
- Optional `KEY_ALIAS` (defaults to `upload`)

If those variables are not supplied, the release variant is not production-signed. Verify the signed release on real devices before distributing it.

## Security-rule tests

The `tests/firestore.rules.test.mjs` suite covers unauthenticated, pending/rejected, approved-and-assigned, unassigned-folder, self-promotion, and admin-invitation cases. The `tests/storage.rules.test.mjs` suite checks real file-byte reads and uploads against Cloud Storage rules. The local-only `firebase.test.json` uses the emulator's default database so tests do not create or alter production databases; production rules remain configured for the named database in `firebase.json`. These tests need to be executed locally with the Firebase Emulator before production deployment. They require Node.js and npm:

```bash
npm install
npm run test:rules
```

Run the tests against the Firebase Emulator before deploying rules. If the Firebase CLI cannot provision the configured named database in the local emulator, adjust the test database ID and emulator configuration to match your Firebase CLI version; do not loosen production rules to make tests pass.

## Notes and limits

- Firebase Android client configuration/API keys are included as public client configuration; they are not service-account credentials. Restrict APIs and rely on Rules/App Check for data protection.
- No live Firebase project was modified by this source patch. Rule deployment, custom-claim bootstrapping, App Check enforcement, Storage bucket availability, OAuth setup, and the release build must be completed and verified in your Firebase/Google Play environment.
- The material and folder authorization model allows at most 16 assigned folder IDs per student so Storage authorization claims stay within Firebase Auth size limits; the app queries only those assigned folders. The admin student and material lists use an expandable first-100/next-100 pagination strategy.
